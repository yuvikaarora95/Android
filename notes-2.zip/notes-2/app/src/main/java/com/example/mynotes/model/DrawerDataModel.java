package com.example.mynotes.model;

public class DrawerDataModel {

    public int icon;
    public String name;

    // Constructor.
    public DrawerDataModel(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }
}