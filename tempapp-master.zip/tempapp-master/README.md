# tempapp
This app will convert temperature from celsius to fahrenheit and vice versa.
